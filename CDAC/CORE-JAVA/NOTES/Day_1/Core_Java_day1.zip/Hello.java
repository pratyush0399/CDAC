public class Hello
{

public static void main(String[] arg)
{

System.out.println("welcome to cdac Bangalore");

}

}












