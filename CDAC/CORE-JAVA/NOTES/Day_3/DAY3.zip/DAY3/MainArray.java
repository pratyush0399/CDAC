
public class MainArray
{

	public static void main(String[] args) 
	{
	
		
		int[] mark = {23,45,67,65};
		
		ArrayManipulation.findsum(mark);
		
		System.out.println("inside the main ");
		for(int ele : mark)
		{
		     System.out.println(ele);
		}
		
		
	}
	
	
}
