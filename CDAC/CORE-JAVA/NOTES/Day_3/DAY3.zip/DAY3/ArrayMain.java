
public class ArrayMain 
{

	public static void main(String[] args) 
	{
	
		int[] num = new int[4] ;
		
		int[] mark = {23,45,67,65};
		
		num[0]  = 10;
		num[1]  = 20;
		num[2]  = 30;
		num[3]  = 40;
		

		System.out.println("number");
		for(int i=0; i<4; i++)
	     {
	      System.out.print(num[i]+ " ");
	     }
		System.out.println();
		System.out.println("mark");
		for(int i=0; i<4; i++)
	     {
	      System.out.print(mark[i]+" ");
	     }
		System.out.println();
		
		System.out.println("mark using for each");
		
		for(int ele    :mark)
		{
			System.out.println(ele);
		}
		
		System.out.println("city name");
		String[] city = {"blr","hyd","pune","mumbai"};
		
		for(String str    :city)
		{
			System.out.print(str+ ", ");
		}
		
		
		
	}
	
}
