
public class ForExample
{

	public static void main(String[] args) 
	{
//		int sum =0;
//		for(int i =0;i<10;i++)
//		{
//			System.out.println(i);
//			sum = sum+i;
//			
//			
//		}
//		
//		System.out.println(sum);
		
		
//		for(int i=0;i<5;i++)
//		{
//			
//			for(int j=0;j<i; j++)
//			{
//				System.out.print("*");
//			}
//			
//			System.out.println("");
//		}
		
		
		
		//usage of break and continue
		
		
//		for(int i =0; i<10 ; i++)
//		{
//			if(i>6)
//			break;
//			
//			System.out.println(i);
//		}
		
		
		for(int i =0; i<10 ; i++)
		{
			if(i%2 !=0)
			continue;
			
			System.out.println(i);
		}
		
			
		
	}
}
