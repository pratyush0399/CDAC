
public class Test 
{
	public static void changeA(int a) {
		a++;
		
	}
	public static void main(String[] args) 
	{
	
		int a = 10;
		
		changeA(a);
		System.out.println(a);
		
	}

	
	
	
}
