
public class HelloMain
{

	public static void main(String[] args) 
	{
	
		Greetings.sayHello();
		
	}
}
