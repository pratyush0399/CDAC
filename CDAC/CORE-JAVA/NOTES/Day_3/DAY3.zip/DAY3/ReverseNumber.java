import java.util.Scanner;

public class ReverseNumber 
{
	
	public static int reverse(int num)
	{
		int rev =0,rem = 0;
		
		while(num!=0)
		{
			
			rem = num%10;
			rev = rev*10 +rem;
			num = num/10;
				
					
		}
		
		return rev;
		
	}
	
	
	public static void sumofNumber(Scanner sc) 
	{
		//example of while
		
		
				int i=0;
				int sum = 0,mark = 0;;
				while(i<=4)
				{
					
					//System.out.println("cdac "+i);
					i++;
					System.out.println("enter the value of  mark");
					mark = sc.nextInt();
					sum = sum+mark;
				}
				
				System.out.println("sum of i = "+sum); 
				
		
	}
	
	public static void sNumberDoWhile(Scanner sc)
	
	{
		//example of while
			
				int i=0;
				int sum = 0,mark = 0;;
				do
				{
					//System.out.println("cdac "+i);
					i++;
					System.out.println("enter the value of  mark");
					mark = sc.nextInt();
					sum = sum+mark;
					
				}while(i<4);
				
				System.out.println("sum of i = "+sum); 
				
		
	}
	
	
	
	

	public static void findchoiceofCenter(int rank)
	{
//		if(rank<2000)
//		{
//			System.out.println("will get in bangalore");
//		}else
//		{
//			System.out.println("may get in bangalore 2nd round");
//		}
		
		
		if(rank<=500)
		{
			System.out.println("will get in pune");
		}else if(rank>500 && rank<=1000)
		{
			System.out.println("will get in bangalore ");
			
		}else if(rank>1000 && rank<2000)
		   {
			System.out.println("will get in HYd");
	    	}
		else 
		{
			System.out.println("not eligible");
		}
		
		
				
	}

	
	
	
	public static void main(String[] args) 
	{
	
		
		
		/*
		 Scanner sc = new Scanner(System.in);
		 * 
		 * int num=0,rev =0;
		 * 
		 * System.out.println("enter the number to reverse"); num =sc.nextInt();
		 * 
		 * 
		 * rev =reverse(num);
		 * 
		 * //System.out.println(reverse(num));
		 * 
		 * System.out.println(rev);
		 * 
		 * sumofNumber(sc);
		 */
		 
		
		Scanner sc = new Scanner(System.in);
		int rank=0;
		//
		
		//  findchoiceofCenter(rank);
		  
		  sNumberDoWhile(sc);
			
		
	}


	


	



	

	
	
	
}
