
public class ArrayManipulation
{

	public static void findsum(int[] mark) 
	{   int sum = 0;
	
	for(int ele : mark)
	{
	    System.out.print(ele+ " ");
	}
		for(int ele : mark)
		{
		     sum = sum+ele;
		}
		System.out.println();
		System.out.println(sum);
		
		mark[2]  = 100;
	}

	

}
