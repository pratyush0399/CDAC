
public class calculater 
{

	public static void add(int a, int b) 
	{
		System.out.println(a+b);
		
	} 
	
	public static void sub(int a, int b) 
	{
		System.out.println(a-b);
		
	} 
	public static void mul(int a, int b) 
	{
		
		System.out.println(a*b);
	} 
	public static void div(int a, int b) 
	{
		System.out.println(a/b);
		
	} 
	
	
}
