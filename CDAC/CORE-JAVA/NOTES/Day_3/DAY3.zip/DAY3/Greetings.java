
public class Greetings 
{

	
	public static void sayHello()
	{
		System.out.println("welcome");
	}
	
}
