import java.util.Scanner;

public class SwitchExample 
{
	
	
	
	
	public static void main(String[] args) 
	{
		Scanner sc = new Scanner(System.in);
		//System.out.println("enter the value of feedback");
		//int feedback = sc.nextInt();
		
//		switch(feedback)
//		{
//		case 4 : System.out.println("excellent");
//		break;
//		case 3 : System.out.println("good");
//		break;
//		case 2 : System.out.println("average");
//		break;
//		case 1 : System.out.println("bad");
//		break;
//		default : System.out.println("not valid input");
//		break;
//	     }
		
		System.out.println("1 for addition");
		System.out.println("2 for subtraction");
		System.out.println("3 for multiplication");
		System.out.println("4 for divition");
		
		
		System.out.println("enter the choice");
		int choice = sc.nextInt();
		
		int a = 10;
		int b = 20;
		switch(choice)
		{
		case 1 : calculater.add(a,b);
		break;
		case 2 : calculater.sub(a,b);
		break;
		case 3 : calculater.mul(a,b);
		break;
		case 4 : calculater.div(a,b);
		break;
		default : System.out.println("not valid input");
		break;
	     }
		
		
		
				
	}

	
	
	
}
